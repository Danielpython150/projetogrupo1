# projetoGrupo1
Projeto Integrador Gp 1 - Proz Tech

Objetivo: apresentar Sprint 1 do projeto integrador.

Nome do Projeto: Rede Veicular Cooperativa
Formato: html
Tema: Construção de um web site de seguro de automóveis.

## Percurso
### Nº 	Etapas - Sprint I 

01 	Definição do tema na Discord - melhor proposta dada por Ramon Rezende.  

02 	Proposta de repositório com Git e GitHub - Rafael Dutra
![Legenda](https://github.com/rafaeldutravalle/projetoGrupo1.git)
  

03 	Primeira proposta de canva - Daniel Neves  
![Legenda]() https://www.canva.com/design/DAGC9X7pzeU/UjGCRgxJnQMfHt0eBKrQzQ/edit  

04 	Segunda proposta de canva - Deisielle Dutra  
![Legenda](https://cdn.discordapp.com/attachments/1227297546670706770/1232141945480937543/73c5679c-f496-45a6-bfaa-f3c4797354a1.jpg?ex=6629b29b&is=6628611b&hm=6bd8c324c3cd7cd1757dfbf7617b02f1906bfea37978a237c5f4e73f8b98a053&) https://www.canva.com/design/DAGDL7gfe_c/yFSDAOE7p98toz5eXYzA4w/edit  

### Nº 	Etapas - Sprint II

01 Renomeando as branchs anteriormente criadas no repositório para adequá-las ao projeto final da página.

02 Criação dos cinco arquivos HTML de acordo com o menu de navegação.

03 Tentativa de escrever os primeiros "HELLO WORLD!" em HTML, com barra de menu e formulário.

## Itegrantes

Deisielle Dutra  
Daniel Neves  
Ramon Rezende  
Rafael Dutra  